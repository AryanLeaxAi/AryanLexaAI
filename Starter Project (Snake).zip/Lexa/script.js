const button = document.getElementById("mic");
const status = document.getElementById("status");

// 👇 Apni Gemini API key yahan paste kar
const API_KEY = AQ.Ab8RN6KAyzXtdJSDhbruMeQ57MCbHb05ioBRBmGjCGaTwyNtIQ;

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;

if (!SpeechRecognition) {
  status.innerText = "❌ Speech Recognition is not supported on this browser.";
} else {

  const recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  button.addEventListener("click", () => {
    status.innerText = "🎤 Listening...";
    recognition.start();
  });

  recognition.onresult = async (event) => {
    const userText = event.results[0][0].transcript;

    status.innerText = "🧑 You: " + userText;

    try {
      const reply = await askGemini(userText);

      status.innerText += "\n\n🤖 Nova: " + reply;

      speak(reply);

    } catch (err) {
      console.error(err);
      status.innerText += "\n\n❌ " + err.message;
    }
  };

  recognition.onerror = (event) => {
    status.innerText = "❌ Mic Error: " + event.error;
  };
}

async function askGemini(prompt) {

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${API_KEY}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text:
                  `You are Nova, a friendly AI voice assistant. Reply naturally in Hinglish.\n\nUser: ${prompt}`
              }
            ]
          }
        ]
      })
    }
  );

  const data = await response.json();

  if (!response.ok) {
    console.log(data);
    throw new Error(data.error?.message || "Gemini API Error");
  }

  return data.candidates[0].content.parts[0].text;
}

function speak(text) {

  speechSynthesis.cancel();

  const speech = new SpeechSynthesisUtterance(text);

  speech.lang = "hi-IN";
  speech.rate = 1;
  speech.pitch = 1;

  speechSynthesis.speak(speech);
}